### Workload für die Woche vom 8. bis 15. März

## HTML Online Tutorials der *codeacademy*

[https://www.codecademy.com/learn/web](https://www.codecademy.com/learn/web)

### unter Tab Syllabus:

* 1 Introduction to HTML: HTML Basics
* 2 HTML Structure: Using Lists: HTML Basics II

**Aufgabe:**

* Mit dem Gelernten bis zum 15. März eine einfache HTML Seite zu einem beliebigen Thema im eigenen github Repo erstellen.

        Name des Repos: wl
        Name der Seite: wl1.html
        Mindestinhalt: Überschrift(en), Absätze, Wörter fett/kursiv, Links, Bild(er), Liste(n)

* E-Mail mit Link zur erstellten Seite an [Klaus Förster](mailto:klaus.foerster@uibk.ac.at)
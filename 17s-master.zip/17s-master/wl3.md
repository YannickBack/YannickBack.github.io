### Workload für die Woche vom 22. bis 29. März

## Javascript Online Tutorials der *codeacademy*

[https://www.codecademy.com/learn/javascript](https://www.codecademy.com/learn/javascript)

### unter Tab Syllabus:

* 1 Getting Started with Programming
* 2 Introduction to Functions in JS
* 3 Introduction to 'For' Loops in JS

**Aufgabe:**

Die Tutorials belegen und **zwei offene Fragen** zum Gelernten bis Dienstag, den 28.3. (abends) an uns **beide** schicken.

E-Mails: [Klaus Förster](mailto:klaus.foerster@uibk.ac.at), [Bernd Öggl](mailto:bernd.oeggl@uibk.ac.at)

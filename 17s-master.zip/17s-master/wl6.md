### Workload für die Woche vom 26. April bis 3. Mai

## Stadtspaziergang Wien erweitern

[https://github.com/webmapping/17s/tree/master/wien](https://github.com/webmapping/17s/tree/master/wien)

**Aufgabe:**

Der letzte Stand des Wien Beispiels aus Session 5 (siehe Link oben) soll im Rahmen der Workload erweitert werden.

### Inhalt der Erweiterung:

* alle mit **TODO** gekennzeichneten Stellen im Skript der Seite index.html (siehe Link oben)
* Ablage aller nötigen Dateien in einem (neuen) github Repo, das über folgende URL erreichbar sein soll:

        https://USERNAME.github.io/wien/index.html

Den Link zum erweiterten Beispiel bitte via E-Mail bis zum **3. Mai, 14:00** an uns senden.

E-Mails: [Klaus Förster](mailto:klaus.foerster@uibk.ac.at), [Bernd Öggl](mailto:bernd.oeggl@uibk.ac.at)

